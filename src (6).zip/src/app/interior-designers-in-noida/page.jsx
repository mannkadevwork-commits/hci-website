import React from "react";
import { FaHome, FaSmile, FaStar } from "react-icons/fa";
import MainLayout from "../layouts/MainLayout";
import BackgroundImageWithHeading from "../components/BackgroundImageWithHeading";

// --- CONFIGURATION ---
export const revalidate = 60;

const getBaseUrl = () => {
  const url =
    process.env.NODE_ENV === "development"
      ? process.env.NEXT_PUBLIC_API_DEV_URL
      : process.env.NEXT_PUBLIC_API_BASE_URL;
  return url || "http://localhost:9999";
};

// --- HELPER: Fetch Noida Data ---
async function getCityData() {
  try {
    const baseURL = getBaseUrl();
    const res = await fetch(`${baseURL}/cms-city`, {
      next: { revalidate: 60 },
    });

    if (!res.ok) return null;

    const contentType = res.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) return null;

    const allCities = await res.json();
    if (!Array.isArray(allCities)) return null;

    const noidaData = allCities.find(
      (city) => city.city_type?.toLowerCase() === "noida"
    );

    return noidaData || null;
  } catch (err) {
    console.error("City Fetch Error:", err);
    return null;
  }
}

// --- HELPER: Fetch SEO Data for Noida ---
async function getSeoData() {
  try {
    const baseURL = getBaseUrl();
    const res = await fetch(`${baseURL}/seo-tag`, {
      next: { revalidate: 60 },
    });

    if (!res.ok) return null;

    const contentType = res.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) return null;

    const allTags = await res.json();
    if (Array.isArray(allTags)) {
      return allTags.find(
        (tag) =>
          tag.page_name === "https://hcinterior.in/interior-designers-in-noida" ||
          tag.page_name?.endsWith("/interior-designers-in-noida")
      );
    }
    return null;
  } catch (err) {
    console.error("SEO Fetch Error:", err);
    return null;
  }
}

// --- DYNAMIC METADATA GENERATION ---
export async function generateMetadata() {
  const seoData = await getSeoData();

  const defaultTitle = "Top Interior Designers in Noida | High Creation Interior";
  const defaultDesc =
    "Looking for the best interior designers in Noida? High Creation Interior offers premium residential and commercial interior design services.";
  const defaultCanonical = "https://hcinterior.in/interior-designers-in-noida";

  return {
    title: seoData?.title || defaultTitle,
    description: seoData?.meta_description || defaultDesc,
    alternates: {
      canonical: seoData?.page_name || defaultCanonical,
    },
    openGraph: {
      title: seoData?.title || defaultTitle,
      description: seoData?.meta_description || defaultDesc,
      url: seoData?.page_name || defaultCanonical,
      type: "website",
    },
  };
}

// --- MAIN SERVER COMPONENT ---
export default async function NoidaCityPage() {
  const cityData = await getCityData();

  const rawTitle = cityData?.main_title || "Interior Designer in Noida";
  const displayTitle =
    typeof rawTitle === "string" ? rawTitle : "Interior Designer in Noida";

  const rawDesc =
    cityData?.main_description ||
    "Premium interior design services tailored for your home and office in Noida.";
  const displayDescription =
    typeof rawDesc === "string" ? rawDesc : "Premium interior design services tailored for your home and office in Noida.";

  return (
    <MainLayout>
      <main>
        {/* Banner Section */}
        <BackgroundImageWithHeading
          sectionBgImages={"contact_wrapper"}
          sectionBgHeading={displayTitle}
          secBgHeadingClass="sec_bgheading_lass"
          sectionBgDescription={displayDescription}
          secBgDesClass={"text-center text-white"}
        />

        {/* Headings & Stats Counter Section */}
        <section className="container my-5 py-4">
          <div className="text-center mb-5">
            <h1 className="fw-bold text-dark mb-3">Interior Designer in Noida</h1>
            <h2 className="text-secondary mb-3">Our Proven Design Process</h2>
            <h3 className="text-muted mb-4">Design Inspiration</h3>
          </div>

          {/* Stats Card Container */}
          <div
            className="card border-0 rounded-4 p-4 p-md-5 shadow-sm"
            style={{ backgroundColor: "#fff8f5" }}
          >
            <div className="row text-center align-items-center">
              {/* 1. Home Renovations */}
              <div
                className="col-md-4 border-end-md mb-4 mb-md-0"
                style={{ borderColor: "#e5e7eb" }}
              >
                <div className="d-flex justify-content-center mb-3">
                  <FaHome size={42} color="#f5a623" />
                </div>
                <h2 className="fw-bold text-dark mb-1" style={{ fontSize: "2.2rem" }}>
                  2680+
                </h2>
                <p
                  className="text-uppercase text-muted small fw-bold mb-0"
                  style={{ letterSpacing: "0.5px" }}
                >
                  HOME RENOVATIONS
                </p>
              </div>

              {/* 2. Happy Customers */}
              <div
                className="col-md-4 border-end-md mb-4 mb-md-0"
                style={{ borderColor: "#e5e7eb" }}
              >
                <div className="d-flex justify-content-center mb-3">
                  <FaSmile size={42} color="#ff7839" />
                </div>
                <h2 className="fw-bold text-dark mb-1" style={{ fontSize: "2.2rem" }}>
                  2660+
                </h2>
                <p
                  className="text-uppercase text-muted small fw-bold mb-0"
                  style={{ letterSpacing: "0.5px" }}
                >
                  HAPPY CUSTOMERS
                </p>
              </div>

              {/* 3. Client Ratings */}
              <div className="col-md-4">
                <div className="d-flex justify-content-center mb-3">
                  <FaStar size={42} color="#2b2b2b" />
                </div>
                <h2 className="fw-bold text-dark mb-1" style={{ fontSize: "2.2rem" }}>
                  4.8/5
                </h2>
                <p
                  className="text-uppercase text-muted small fw-bold mb-0"
                  style={{ letterSpacing: "0.5px" }}
                >
                  CLIENT RATINGS
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Dynamic City Information Section */}
        {cityData && (
          <section className="container my-5">
            <div className="row mx-0 g-4 align-items-center">
              <div className="col-lg-6">
                <img
                  src={cityData.location_image || "/images/services/1-min.png"}
                  alt="Interior Designers in Noida"
                  className="img-fluid rounded shadow"
                  decoding="async"
                  loading="lazy"
                />
              </div>
              <div className="col-lg-6">
                <h3 className="mb-4">{displayTitle}</h3>
                <p className="text-muted" style={{ lineHeight: "1.8" }}>
                  {displayDescription}
                </p>
                <a
                  href="/contact"
                  className="know_more px-4 py-2 mt-3 d-inline-block text-decoration-none"
                >
                  Get a Free Estimate
                </a>
              </div>
            </div>
          </section>
        )}
      </main>
    </MainLayout>
  );
}