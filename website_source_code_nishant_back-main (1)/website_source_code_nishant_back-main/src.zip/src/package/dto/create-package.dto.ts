export class CreatePackageDto {}
