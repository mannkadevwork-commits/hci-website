export class CreatePropertySubTypeDto {}
