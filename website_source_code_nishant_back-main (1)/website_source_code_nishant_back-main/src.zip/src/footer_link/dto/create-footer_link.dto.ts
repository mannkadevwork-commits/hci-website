export class CreateFooterLinkDto {}
