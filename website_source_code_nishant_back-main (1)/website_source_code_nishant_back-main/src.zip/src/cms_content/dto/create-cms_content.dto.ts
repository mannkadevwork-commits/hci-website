export class CreateCmsContentDto {}
