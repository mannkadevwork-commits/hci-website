export class CreateManageJobDto {}
