export class CreateSiteSettingDto {}
