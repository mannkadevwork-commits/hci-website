export class CreateSizeTypeDto {}
