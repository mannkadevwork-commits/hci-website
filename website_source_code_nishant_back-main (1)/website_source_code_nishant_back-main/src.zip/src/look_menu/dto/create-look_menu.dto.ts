export class CreateLookMenuDto {}
