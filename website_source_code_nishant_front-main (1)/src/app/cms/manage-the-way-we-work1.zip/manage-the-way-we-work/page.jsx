"use client";

import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { FaSave, FaPlus, FaTrash } from "react-icons/fa";
import api from "@/utils/api";
import AuthMainLayout from "../../layouts/auth/AuthMainLayout";

export default function ManageTheWayWeWork() {
  const [contentId, setContentId] = useState(null);
  console.log("contentId =", contentId);

  const [heading, setHeading] = useState("The Way We Work");
  const [headingColor, setHeadingColor] = useState("#ffffff"); // New State

  const [backgroundImage, setBackgroundImage] = useState(null);
  const [backgroundPreview, setBackgroundPreview] = useState("");
  const [bgSize, setBgSize] = useState("cover"); // New State

  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      const res = await api.get(
        "/cms-content/home_page_content_the_way_we_work"
      );

      if (!res.data) return;

      const record = Array.isArray(res.data) ? res.data[0] : res.data;

      if (!record) return;

      setContentId(record.id);
      const content = record.json_content || {};

      setHeading(content.heading || "The Way We Work");
      setHeadingColor(content.headingColor || "#ffffff"); 
      setBgSize(content.bgSize || "cover");               
      
      // 🌟 THE FIX: Force old cards to adopt default values if they are empty
      const hydratedCards = (content.cards || []).map((card) => ({
        ...card,
        textColor: card.textColor || "#ffffff", // Default text color
        iconColor: card.iconColor || "#343a40", // Default background block color
        iconSize: card.iconSize || 120,
      }));
      setCards(hydratedCards);

      setBackgroundPreview(content.bg_image || "");
    } catch (err) {
      console.log(err);
      toast.error("Failed to load data.");
    } finally {
      setLoading(false);
    }
  };

  const handleCardChange = (index, field, value) => {
    const updated = [...cards];
    updated[index][field] = value;
    setCards(updated);
  };

  const handleIconChange = (index, file) => {
    const updated = [...cards];
    updated[index].icon = file;
    updated[index].preview = URL.createObjectURL(file);
    setCards(updated);
  };

  const addCard = () => {
    setCards([
      ...cards,
      {
        number: "",
        title: "",
        description: "",
        buttonText: "Know More",
        buttonLink: "",
        icon: null,
        preview: "",
        iconSize: 44,         // New default
        textColor: "#ffffff", // New default
        iconColor: "#ffffff", // New default
      },
    ]);
  };

  const deleteCard = (index) => {
    const updated = [...cards];
    updated.splice(index, 1);
    setCards(updated);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      console.log("contentId =", contentId);

      const formData = new FormData();

      // Strip File objects AND the transient blob "preview" URL out of the
      // JSON payload before it's saved. The actual files travel separately
      // as multipart fields below, and the backend fills the real filename
      // back in server-side. `preview` is a blob: URL created client-side
      // via URL.createObjectURL() - it only lives for this browser tab's
      // session, so persisting it to the DB produces a dead link on the
      // next page load/reload.
      const updatedCards = cards.map(({ preview, ...card }) => ({
        ...card,
        icon: typeof card.icon === "string" ? card.icon : "",
      }));

      formData.append(
        "json_content",
        JSON.stringify({
          heading,
          headingColor, // Save new field
          bgSize,       // Save new field
          cards: updatedCards,
        })
      );

      // 🌟 FIX: icon files must be sent whenever a card has a NEW icon file,
      // regardless of whether the background image was also changed.
      // We also record which card index each uploaded icon belongs to,
      // because previously "icons" was appended only for cards that had a
      // new File - so if card #1 kept its old icon and card #2 got a new
      // one, the single uploaded file landed at icons[0] and the backend
      // (which matched icons[index] to cards[index] positionally) attached
      // it to the WRONG card.
      const iconIndices = [];
      cards.forEach((card, idx) => {
        if (card.icon instanceof File) {
          formData.append("icons", card.icon);
          iconIndices.push(idx);
        }
      });
      formData.append("icon_indices", JSON.stringify(iconIndices));

      // 🌟 FIX: background image is no longer gated behind the icons logic,
      // and icons are no longer gated behind the background image being set.
      if (backgroundImage instanceof File) {
        formData.append("image", backgroundImage);
      }

      let response;

      if (contentId) {
        // Update existing record
        response = await api.patch(
          `/cms-content/update-with-image/${contentId}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
      } else {
        // Create new record
        response = await api.post(
          "/cms-content/home_page_content_the_way_we_work",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
      }

      toast.success("Saved Successfully");
      fetchData();
    } catch (err) {
      console.log(err);
      toast.error("Save Failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AuthMainLayout>
        <div
          className="d-flex justify-content-center align-items-center"
          style={{ minHeight: "60vh" }}
        >
          <div className="spinner-border text-warning" />
        </div>
      </AuthMainLayout>
    );
  }

  return (
    <AuthMainLayout>
      <div className="container py-5">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="fw-bold">Manage {heading}</h2>

          <button
            className="btn btn-success"
            disabled={saving}
            onClick={handleSave}
          >
            <FaSave className="me-2" />
            {saving ? "Saving..." : "Save"}
          </button>
        </div>

        {/* Heading Settings */}
        <div className="card shadow-sm border-0 mb-4">
          <div className="card-body row">
            <div className="col-md-8">
              <label className="form-label fw-bold">Section Heading</label>
              <input
                className="form-control"
                value={heading}
                onChange={(e) => setHeading(e.target.value)}
              />
            </div>
            <div className="col-md-4">
              <label className="form-label fw-bold">Heading Color</label>
              <input
                type="color"
                className="form-control form-control-color w-100"
                value={headingColor}
                onChange={(e) => setHeadingColor(e.target.value)}
                title="Choose heading color"
              />
            </div>
          </div>
        </div>

        {/* Background Settings */}
        <div className="card shadow-sm border-0 mb-4">
          <div className="card-body row">
            <div className="col-md-8">
              <label className="form-label fw-bold">Background Image</label>
              <input
                type="file"
                className="form-control"
                onChange={(e) => {
                  setBackgroundImage(e.target.files[0]);
                  setBackgroundPreview(URL.createObjectURL(e.target.files[0]));
                }}
              />
              {backgroundPreview && (
                <img
                  src={backgroundPreview}
                  alt="Background Preview"
                  className="mt-3 rounded border"
                  style={{ width: "300px", maxWidth: "100%" }}
                />
              )}
            </div>
            <div className="col-md-4">
              <label className="form-label fw-bold">Background Size</label>
              <select
                className="form-select"
                value={bgSize}
                onChange={(e) => setBgSize(e.target.value)}
              >
                <option value="cover">Cover (Fills Area)</option>
                <option value="contain">Contain (Fits inside)</option>
                <option value="100% 100%">Stretch (100% x 100%)</option>
                <option value="auto">Auto (Original Size)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Cards */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h4 className="fw-bold">Process Cards</h4>
          <button className="btn btn-primary" onClick={addCard}>
            <FaPlus className="me-2" />
            Add Card
          </button>
        </div>

        {cards.map((card, index) => (
          <div key={index} className="card shadow-sm border-0 mb-4">
            <div className="card-body">
              <div className="row">
                <div className="col-md-2">
                  <label className="form-label">Number</label>
                  <input
                    className="form-control"
                    value={card.number}
                    onChange={(e) =>
                      handleCardChange(index, "number", e.target.value)
                    }
                  />
                </div>

                <div className="col-md-10">
                  <label className="form-label">Title</label>
                  <input
                    className="form-control"
                    value={card.title}
                    onChange={(e) =>
                      handleCardChange(index, "title", e.target.value)
                    }
                  />
                </div>
              </div>

              <div className="mt-3">
                <label className="form-label">Description</label>
                <textarea
                  rows={4}
                  className="form-control"
                  value={card.description}
                  onChange={(e) =>
                    handleCardChange(index, "description", e.target.value)
                  }
                />
              </div>

              <div className="row mt-3">
                <div className="col-md-6">
                  <label className="form-label">Button Text</label>
                  <input
                    className="form-control"
                    value={card.buttonText}
                    onChange={(e) =>
                      handleCardChange(index, "buttonText", e.target.value)
                    }
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label">Button Link</label>
                  <input
                    className="form-control"
                    value={card.buttonLink}
                    onChange={(e) =>
                      handleCardChange(index, "buttonLink", e.target.value)
                    }
                  />
                </div>
              </div>

              {/* Advanced Styling Options for Cards */}
              <div className="row mt-4 p-3 bg-light rounded align-items-end">
                <h6 className="fw-bold mb-3">Card Styles & Icon</h6>
                <div className="col-md-4">
                  <label className="form-label">Card Icon</label>
                  <input
                    type="file"
                    className="form-control"
                    onChange={(e) => handleIconChange(index, e.target.files[0])}
                  />
                  {(() => {
                    // Only trust `preview` (a blob: URL) when the user just
                    // picked a new File in this session - it's dead after any
                    // reload. Otherwise fall back to the persisted icon URL.
                    const imgSrc =
                      card.icon instanceof File
                        ? card.preview
                        : typeof card.icon === "string"
                        ? card.icon
                        : "";

                    return (
                      imgSrc && (
                        <div className="mt-3">
                          <img
                            src={imgSrc}
                            className="border rounded bg-dark p-1"
                            style={{ width: 80, objectFit: "contain" }}
                            alt="Card icon preview"
                          />
                        </div>
                      )
                    );
                  })()}
                </div>

                <div className="col-md-3">
                  <label className="form-label">Icon Size (px)</label>
                  <input
                    type="range"
                    className="form-range"
                    min="20"
                    max="150"
                    value={card.iconSize || 44}
                    onChange={(e) =>
                      handleCardChange(index, "iconSize", Number(e.target.value))
                    }
                  />
                  <div className="text-muted text-center fw-bold">
                    {card.iconSize || 44}px
                  </div>
                </div>

                <div className="col-md-2">
                  <label className="form-label">Icon Color</label>
                  <input
                    type="color"
                    className="form-control form-control-color w-100"
                    value={card.iconColor || "#ffffff"}
                    onChange={(e) =>
                      handleCardChange(index, "iconColor", e.target.value)
                    }
                  />
                </div>

                <div className="col-md-3">
                  <label className="form-label">Text Color</label>
                  <input
                    type="color"
                    className="form-control form-control-color w-100"
                    value={card.textColor || "#ffffff"}
                    onChange={(e) =>
                      handleCardChange(index, "textColor", e.target.value)
                    }
                  />
                </div>
              </div>

              <div className="text-end mt-4">
                <button
                  className="btn btn-danger"
                  onClick={() => deleteCard(index)}
                >
                  <FaTrash className="me-2" />
                  Delete Card
                </button>
              </div>
            </div>
          </div>
        ))}

      </div>
    </AuthMainLayout>
  );
}